import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt


# 가상 데이터 만들기
x=norm.rvs(size=10, loc=3, scale=2)
x.sort()
x
0.2 * x[1] + 0.8 * x[2]


# 백분위수 예제 (25 백분위수)
x=np.array([155, 126, 27, 82, 115,
            140, 73, 92, 110, 134])
x.sort()
x

## j, h 구하기
n=len(x); p=25
(n-1)*(p/100)+1
j=int((n-1)*(p/100)+1) 
h=((n-1)*(p/100)+1) % 1
q_25=(1-h)*x[j-1] + h*x[j]
q_25

np.percentile(x, 25)
np.percentile(x, 50)
np.percentile(x, 75)

# 표본분산 n-1 vs. n
# 1. n이 작은경우 n-1로 나눈 것이 좀 더 정확한 추정값
# 2. n-1로 나눈 값이 이루는 분포 중심이 실제 모분산과 동일
# (기대값이 같다, 불편추정량)
# 균일분포 (3, 7)
# 분산: 1.3333
# 표본분산 n=10 의 히스토그램을 그려보면 

# 나의 데이터가 정규분포를 따를까?
np.percentile(x, 25) # 데이터 25백분위수
norm.ppf(0.25, loc=x.mean(), scale=x.std(ddof=1)) # 40


data_x=np.array([4.62, 4.09, 6.2, 8.24, 0.77, 5.55, 3.11,
                 11.97, 2.16, 3.24, 10.91, 11.36, 0.87])

import scipy.stats as sp
import matplotlib.pyplot as plt
sp.probplot(data_x, dist="norm", plot=plt)


# ECDF
from statsmodels.distributions.empirical_distribution import ECDF
data_x = np.array([4.62, 4.09, 6.2, 8.24, 0.77, 5.55, 3.11,
                   11.97, 2.16, 3.24, 10.91, 11.36, 0.87])
# data_x=norm.rvs(size=2000, loc=3, scale=2)
ecdf = ECDF(data_x)
x = np.linspace(min(data_x), max(data_x))
y = ecdf(x)
k=np.linspace(-2, 12, 100)
cdf_k=norm.cdf(k,
               loc=data_x.mean(),
               scale=data_x.std(ddof=1))
plt.plot(x,y,marker='_', linestyle='none')
plt.plot(k, cdf_k, color="red")
plt.title("Estimated CDF")
plt.xlabel("X-axis")
plt.ylabel("ECDF")
plt.show()


k=np.linspace(-5, 15, 100)
f_x=norm.cdf(k,
             loc=data_x.mean(),
             scale=data_x.std(ddof=1))
plt.plot(k, f_x * (1-f_x), color="red")
plt.xlabel("X")
plt.ylabel("F(x)(1-F(x))")
plt.show()


from scipy.stats import anderson, norm
sample_data = np.array([4.62, 4.09, 6.2, 8.24, 0.77, 5.55, 3.11,
                        11.97, 2.16, 3.24, 10.91, 11.36, 0.87])
result = anderson(sample_data, dist='norm')
result[0] # 검정통계량
result[1] # 임계값
result[2] # 유의수준

# 카이제곱 분포 알아보기
from scipy.stats import chi2

# 1. 표준정규분포 확률변수를 사용해서 만들수 있다.
# Z: 표준정규분포 (평균:0, 분산:1)
# X = Z^2 ~ 카이제곱(1)
# X = Z1^2 + Z2^2 + Z3^2 ~ 카이제곱(3)
# 2. 나오는 값의 범위가 0~무한대


# 표준정규분포에서 3개 샘플 → 제곱합
z = norm.rvs(size=3 * 10000)
z = np.reshape(z, (10000, 3))
def sum_of_squares(x):
    return np.sum(x ** 2)
chi_samples = np.apply_along_axis(sum_of_squares, axis=1, arr=z)

# 카이제곱분포 (df=3)
k = np.linspace(0, 20, 200)
pdf_chi = chi2.pdf(k, df=3)
plt.hist(chi_samples, bins=30, density=True, edgecolor="black", alpha=0.5)
plt.plot(k, pdf_chi, label='Chi-squared(df=3)', color='green')
plt.title('Sum of squares of 3 N(0,1) vs Chi-squared(df=3)')
plt.legend()
plt.show()

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import binom, norm

# 이항분포 근사 시각화
n, p = 1000, 0.5
x = binom.rvs(n=n, p=p, size=10000)

# 정규 근사값 (mean=np, std=sqrt(np(1-p)))
k = np.linspace(min(x), max(x), 100)
pdf_norm = norm.pdf(k, loc=n*p, scale=np.sqrt(n*p*(1-p)))
plt.hist(x, bins=30, density=True, edgecolor="black", alpha=0.5)
plt.plot(k, pdf_norm, label='Normal Approx', color='red')
plt.title('Binomial(n=1000, p=0.5) vs Normal Approximation')
plt.legend()
plt.show()

binom.cdf(460, n=1000, p=0.45)
norm.cdf(460, loc=450, scale=np.sqrt(1000*0.45*0.55))

# 1 표본 분산 검정
x=np.array([10.67, 9.92, 9.62, 9.53, 9.14,
            9.74, 8.45, 12.65, 11.47, 8.62])
n=len(x)
s_2=x.var(ddof=1)
v_value=(n-1)*s_2 / 1.3
v_value

p_value=chi2.sf(v_value, df=n-1)
p_value

1/(2.7/(n-1)*s_2)
1/(19/(n-1)*s_2)

1-chi2.cdf(15.55, df=1)